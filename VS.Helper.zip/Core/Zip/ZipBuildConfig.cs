using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace VS.Helper.Core.Zip;

internal sealed class ZipBuildConfig
{
    public const string FileName = "VS.Helper.Zip.xml";

    public string Root { get; set; } = ".";
    public string OutputDir { get; set; } = ".";
    public string ArchiveName { get; set; } = "$(SolutionName)_$(Date)_$(Time).zip";
    public string StartProject { get; set; } = string.Empty;
    public bool IncludeProjectClosure { get; set; } = true;
    public bool IncludeManifest { get; set; } = true;
    public bool IncludeSolutionFiles { get; set; } = true;
    public List<string> Include { get; } = new();
    public List<string> Exclude { get; } = new();

    public static ZipBuildConfig LoadOrCreateDefault(string solutionPath)
    {
        string solutionDir = Path.GetDirectoryName(solutionPath) ?? Environment.CurrentDirectory;
        string configPath = Path.Combine(solutionDir, FileName);

        if (!File.Exists(configPath))
            return CreateDefault(solutionPath);

        XDocument document = XDocument.Load(configPath);
        XElement root = document.Root ?? throw new InvalidOperationException($"Файл {FileName} пустой.");

        ZipBuildConfig config = new()
        {
            Root = Read(root, "Root", "."),
            OutputDir = Read(root, "OutputDir", "."),
            ArchiveName = Read(root, "ArchiveName", "$(SolutionName)_$(Date)_$(Time).zip"),
            StartProject = Read(root, "StartProject", string.Empty),
            IncludeProjectClosure = ReadBool(root, "IncludeProjectClosure", true),
            IncludeManifest = ReadBool(root, "IncludeManifest", true),
            IncludeSolutionFiles = ReadBool(root, "IncludeSolutionFiles", true),
        };

        config.Include.AddRange(ReadItems(root, "Include", "File"));
        config.Exclude.AddRange(ReadItems(root, "Exclude", "Pattern"));

        if (config.Include.Count == 0 && !config.IncludeProjectClosure)
            config.IncludeProjectClosure = true;

        EnsureDefaultExcludes(config);
        return config;
    }

    public static ZipBuildConfig CreateDefault(string solutionPath)
    {
        string solutionName = Path.GetFileNameWithoutExtension(solutionPath);

        ZipBuildConfig config = new()
        {
            Root = ".",
            OutputDir = ".",
            ArchiveName = solutionName + "_$(Date)_$(Time).zip",
            IncludeProjectClosure = true,
            IncludeManifest = true,
            IncludeSolutionFiles = true,
        };

        string firstProject = SolutionProjectScanner.GetProjects(solutionPath).FirstOrDefault() ?? string.Empty;
        if (!string.IsNullOrWhiteSpace(firstProject))
        {
            string solutionDir = Path.GetDirectoryName(solutionPath) ?? Environment.CurrentDirectory;
            config.StartProject = ZipPath.GetRelativePath(solutionDir, firstProject);
        }

        config.Include.Add(Path.GetFileName(solutionPath));
        config.Include.Add(FileName);
        config.Include.Add("README.md");
        config.Include.Add("LICENSE*");
        config.Include.Add("Directory.Build.*");
        config.Include.Add("global.json");
        config.Include.Add("NuGet.config");

        EnsureDefaultExcludes(config);
        return config;
    }

    public void Save(string solutionPath)
    {
        string solutionDir = Path.GetDirectoryName(solutionPath) ?? Environment.CurrentDirectory;
        string path = Path.Combine(solutionDir, FileName);

        XDocument document = new(
            new XElement("VSHelperZip",
                new XElement("Root", Root),
                new XElement("OutputDir", OutputDir),
                new XElement("ArchiveName", ArchiveName),
                new XElement("StartProject", StartProject),
                new XElement("IncludeProjectClosure", IncludeProjectClosure),
                new XElement("IncludeSolutionFiles", IncludeSolutionFiles),
                new XElement("IncludeManifest", IncludeManifest),
                new XElement("Include", Include.Select(x => new XElement("File", x))),
                new XElement("Exclude", Exclude.Select(x => new XElement("Pattern", x)))));

        document.Save(path);
    }

    private static string Read(XElement root, string name, string defaultValue)
        => (string?)root.Element(name) ?? defaultValue;

    private static bool ReadBool(XElement root, string name, bool defaultValue)
    {
        string value = Read(root, name, defaultValue.ToString());
        return bool.TryParse(value, out bool result) ? result : defaultValue;
    }

    private static IEnumerable<string> ReadItems(XElement root, string parentName, string itemName)
        => root.Element(parentName)?.Elements(itemName).Select(x => (string?)x).Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x!)
           ?? Enumerable.Empty<string>();

    private static void EnsureDefaultExcludes(ZipBuildConfig config)
    {
        string[] defaults =
        {
            "bin/**", "obj/**", ".vs/**", ".git/**", ".idea/**", ".vscode/**",
            "packages/**", "TestResults/**", "*.user", "*.suo", "*.cache", "*.log",
            "*.zip", "*.nupkg", "*.vsix"
        };

        foreach (string item in defaults)
            if (!config.Exclude.Any(x => string.Equals(x, item, StringComparison.OrdinalIgnoreCase)))
                config.Exclude.Add(item);
    }
}
