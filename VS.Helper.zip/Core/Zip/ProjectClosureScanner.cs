using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace VS.Helper.Core.Zip;

internal sealed class ProjectClosureScanner
{
    private static readonly HashSet<string> ExplicitItemNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "Compile", "EmbeddedResource", "Content", "None", "Resource", "Page", "ApplicationDefinition",
        "AdditionalFiles", "Analyzer", "NativeReference", "PackageReference", "Reference"
    };

    public IEnumerable<string> Collect(string solutionPath, ZipBuildConfig config, string rootDir)
    {
        Queue<string> queue = new();
        HashSet<string> visited = new(StringComparer.OrdinalIgnoreCase);

        string start = ResolveStartProject(solutionPath, config, rootDir);
        if (!string.IsNullOrWhiteSpace(start) && File.Exists(start))
            queue.Enqueue(start);
        else
            foreach (string project in SolutionProjectScanner.GetProjects(solutionPath))
                queue.Enqueue(project);

        while (queue.Count > 0)
        {
            string projectPath = Path.GetFullPath(queue.Dequeue());
            if (!File.Exists(projectPath) || !visited.Add(projectPath))
                continue;

            yield return projectPath;

            foreach (string file in CollectProjectDirectoryFiles(projectPath))
                yield return file;

            foreach (string reference in GetProjectReferences(projectPath))
            {
                yield return reference;
                if (!visited.Contains(reference))
                    queue.Enqueue(reference);
            }
        }
    }

    private static string ResolveStartProject(string solutionPath, ZipBuildConfig config, string rootDir)
    {
        if (!string.IsNullOrWhiteSpace(config.StartProject))
        {
            string configured = Path.GetFullPath(Path.Combine(rootDir, config.StartProject));
            if (File.Exists(configured))
                return configured;
        }

        return SolutionProjectScanner.GetProjects(solutionPath).FirstOrDefault() ?? string.Empty;
    }

    private static IEnumerable<string> CollectProjectDirectoryFiles(string projectPath)
    {
        string projectDir = Path.GetDirectoryName(projectPath) ?? Environment.CurrentDirectory;

        foreach (string file in Directory.EnumerateFiles(projectDir, "*.*", SearchOption.AllDirectories))
            yield return Path.GetFullPath(file);

        foreach (string explicitFile in GetExplicitProjectFiles(projectPath))
            yield return explicitFile;
    }

    private static IEnumerable<string> GetProjectReferences(string projectPath)
    {
        string projectDir = Path.GetDirectoryName(projectPath) ?? Environment.CurrentDirectory;
        XDocument document;

        try { document = XDocument.Load(projectPath); }
        catch { yield break; }

        foreach (XElement item in document.Descendants().Where(x => x.Name.LocalName == "ProjectReference"))
        {
            string include = (string?)item.Attribute("Include") ?? string.Empty;
            if (string.IsNullOrWhiteSpace(include))
                continue;

            string referencePath = Path.GetFullPath(Path.Combine(projectDir, include));
            if (File.Exists(referencePath))
                yield return referencePath;
        }
    }

    private static IEnumerable<string> GetExplicitProjectFiles(string projectPath)
    {
        string projectDir = Path.GetDirectoryName(projectPath) ?? Environment.CurrentDirectory;
        XDocument document;

        try { document = XDocument.Load(projectPath); }
        catch { yield break; }

        foreach (XElement item in document.Descendants().Where(x => ExplicitItemNames.Contains(x.Name.LocalName)))
        {
            string include = (string?)item.Attribute("Include") ?? string.Empty;
            if (string.IsNullOrWhiteSpace(include) || include.Contains("$"))
                continue;

            foreach (string file in Expand(projectDir, include))
                if (File.Exists(file))
                    yield return file;
        }
    }

    private static IEnumerable<string> Expand(string projectDir, string include)
    {
        include = include.Replace('/', Path.DirectorySeparatorChar);
        if (!include.Contains("*") && !include.Contains("?"))
        {
            yield return Path.GetFullPath(Path.Combine(projectDir, include));
            yield break;
        }

        string root = projectDir;
        string pattern = include;
        SearchOption option = SearchOption.TopDirectoryOnly;
        int star = include.IndexOfAny(new[] { '*', '?' });
        int slash = include.LastIndexOf(Path.DirectorySeparatorChar, Math.Max(0, star));

        if (include.Contains("**"))
        {
            int idx = include.IndexOf("**", StringComparison.Ordinal);
            string prefix = include.Substring(0, idx).TrimEnd(Path.DirectorySeparatorChar);
            if (!string.IsNullOrWhiteSpace(prefix))
                root = Path.Combine(projectDir, prefix);
            pattern = Path.GetFileName(include);
            option = SearchOption.AllDirectories;
        }
        else if (slash >= 0)
        {
            root = Path.Combine(projectDir, include.Substring(0, slash));
            pattern = include.Substring(slash + 1);
        }

        if (!Directory.Exists(root))
            yield break;

        foreach (string file in Directory.EnumerateFiles(root, pattern, option))
            yield return Path.GetFullPath(file);
    }
}
