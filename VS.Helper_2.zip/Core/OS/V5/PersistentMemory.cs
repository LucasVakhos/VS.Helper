using System.Text.Json;

public class PersistentMemory
{
    private const string FILE = "vshelper_memory.json";

    public Dictionary<string, string> Load()
    {
        if (!File.Exists(FILE)) return new();
        return JsonSerializer.Deserialize<Dictionary<string,string>>(File.ReadAllText(FILE)) ?? new();
    }

    public void Save(string key, string value)
    {
        var data = Load();
        data[key] = value;
        File.WriteAllText(FILE, JsonSerializer.Serialize(data, new JsonSerializerOptions{WriteIndented=true}));
    }
}