public class EventBus
{
    public event Action<string,string>? OnEvent;

    public void Emit(string type, string data)
    {
        OnEvent?.Invoke(type,data);
        Console.WriteLine($"[V5] {type}: {data}");
    }
}