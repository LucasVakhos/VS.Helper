public class SwarmEngineV5
{
    private readonly EventBus _bus;
    private readonly PersistentMemory _memory;

    public SwarmEngineV5(EventBus bus, PersistentMemory memory)
    {
        _bus = bus;
        _memory = memory;
    }

    public string Process(string command, Dictionary<string,string> context)
    {
        _bus.Emit("swarm.input", command);

        var a = $"Analyzer:{command}";
        var b = $"Optimizer:{command}";
        var c = $"Validator:{command}";

        var result = $"{a}|{b}|{c}";

        _bus.Emit("swarm.output", result);
        return result;
    }
}