using System.IO.Compression;

public class ZipEngine
{
    public void Build(string path, string outZip)
    {
        ZipFile.CreateFromDirectory(path, outZip);
    }
}