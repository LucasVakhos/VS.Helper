using System.Windows;
using System.Windows.Controls;

public partial class ZipToolWindowControl : System.Windows.Controls.UserControl
{
    public ZipToolWindowControl()
    {
        InitializeComponent();
    }

    private void Build(object sender, RoutedEventArgs e)
    {
        var zip = new ZipEngine();
        zip.Build("C:\\Project", "C:\\out.zip");
    }
}